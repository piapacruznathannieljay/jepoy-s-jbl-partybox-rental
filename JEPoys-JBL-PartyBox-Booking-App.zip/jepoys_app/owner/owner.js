let currentDate = new Date();
let selectedDate = null;
let bookings = [];

const $ = id => document.getElementById(id);

function isoDate(d){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
function formatDate(date){return new Intl.DateTimeFormat('en-PH',{month:'long',day:'numeric',year:'numeric'}).format(new Date(date+'T00:00:00'));}
function esc(v=''){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}
function statusClass(s){return String(s||'pending').toLowerCase();}

async function signIn(e){
 e.preventDefault();
 const msg=$('loginMessage');
 if(!window.supabaseClient){msg.textContent='Configure owner-config.js first.';return;}
 msg.textContent='Signing in…';
 const {error}=await window.supabaseClient.auth.signInWithPassword({email:$('loginEmail').value.trim(),password:$('loginPassword').value});
 if(error){msg.textContent=error.message;return;}
 await showApp();
}
async function showApp(){
 $('loginView').classList.add('hidden'); $('appView').classList.remove('hidden'); await loadBookings(); renderCalendar();
}
async function loadBookings(){
 const {data,error}=await window.supabaseClient.from('bookings').select('*').order('booking_date',{ascending:true}).order('created_at',{ascending:true});
 if(error){console.error(error); alert('Could not load bookings: '+error.message); return;}
 bookings=data||[];
 if(selectedDate) renderDay(selectedDate);
 renderCalendar();
}
function renderCalendar(){
 const y=currentDate.getFullYear(),m=currentDate.getMonth();
 $('monthTitle').textContent=new Intl.DateTimeFormat('en-PH',{month:'long',year:'numeric'}).format(currentDate);
 const first=new Date(y,m,1), start=new Date(y,m,1-first.getDay());
 const grid=$('calendarGrid'); grid.innerHTML='';
 for(let i=0;i<42;i++){
  const d=new Date(start); d.setDate(start.getDate()+i); const date=isoDate(d);
  const cell=document.createElement('div'); cell.className='day'+(d.getMonth()!==m?' muted':'')+(date===isoDate(new Date())?' today':'');
  cell.innerHTML=`<div class="num">${d.getDate()}</div>`;
  bookings.filter(b=>b.booking_date===date && b.status!=='cancelled').slice(0,3).forEach(b=>{const ev=document.createElement('div');ev.className='event '+statusClass(b.status);ev.textContent=b.customer_name;cell.appendChild(ev);});
  const count=bookings.filter(b=>b.booking_date===date && b.status!=='cancelled').length;
  if(count>3){const more=document.createElement('div');more.className='event';more.textContent=`+${count-3} more`;cell.appendChild(more);}
  cell.addEventListener('click',()=>{selectedDate=date;renderDay(date);}); grid.appendChild(cell);
 }
}
function renderDay(date){
 $('selectedDate').textContent=formatDate(date);
 const list=$('dayBookings');
 const dayBookings=bookings.filter(b=>b.booking_date===date);
 if(!dayBookings.length){list.innerHTML='<div class="empty">No bookings for this date.</div>';return;}
 list.innerHTML=dayBookings.map(b=>`<article class="booking">
  <div class="booking-top"><h3>${esc(b.customer_name)}</h3><span class="status ${statusClass(b.status)}">${esc(b.status)}</span></div>
  <div class="details">📦 ${esc(b.package_name)}<br>📞 ${esc(b.phone)}<br>📍 ${esc(b.delivery_address)}<br>🚗 ${Number(b.distance_km).toFixed(2)} km · 🚚 ${Number(b.delivery_fee)===0?'FREE':'₱'+Number(b.delivery_fee).toLocaleString()}</div>
  <div class="actions">
   <button class="accent" onclick="replyBooking('${b.id}')">💬 Reply</button>
   <button onclick="openMap(${b.latitude},${b.longitude})">🗺️ Map</button>
   <button onclick="callCustomer('${esc(b.phone)}')">📞 Call</button>
   <button onclick="openNotes('${b.id}')">📝 Notes</button>
   <button onclick="setStatus('${b.id}','confirmed')">✅ Confirm</button>
   <button onclick="setStatus('${b.id}','completed')">☑ Completed</button>
   <button onclick="setStatus('${b.id}','cancelled')">❌ Cancel</button>
  </div>
 </article>`).join('');
}
function replyBooking(){window.open(BUSINESS_MESSENGER_URL,'_blank');}
function openMap(lat,lng){window.open(`https://www.google.com/maps?q=${lat},${lng}`,'_blank');}
function callCustomer(phone){window.location.href='tel:'+phone;}
async function setStatus(id,status){const {error}=await window.supabaseClient.from('bookings').update({status}).eq('id',id);if(error)alert(error.message);else await loadBookings();}
function openNotes(id){const b=bookings.find(x=>x.id===id);if(!b)return;$('modalContent').innerHTML=`<h2>📝 Notes — ${esc(b.customer_name)}</h2><p class="details">${formatDate(b.booking_date)} · ${esc(b.package_name)}</p><textarea id="noteText" placeholder="Add your private notes…">${esc(b.owner_notes||'')}</textarea><div class="modal-actions"><button class="primary" onclick="saveNotes('${id}')">Save Notes</button></div>`;$('bookingModal').classList.remove('hidden');}
async function saveNotes(id){const notes=$('noteText').value;const {error}=await window.supabaseClient.from('bookings').update({owner_notes:notes}).eq('id',id);if(error){alert(error.message);return;}$('bookingModal').classList.add('hidden');await loadBookings();}
function openAddBooking(){
 const defaultDate=selectedDate||isoDate(new Date());
 $('modalContent').innerHTML=`<h2>＋ Add Booking</h2><form id="manualForm"><input class="note-input" id="mName" placeholder="Customer name" required><input class="note-input" id="mPhone" placeholder="Contact number" required><input class="note-input" id="mPackage" placeholder="Package" required><input class="note-input" id="mDate" type="date" value="${defaultDate}" required><textarea id="mAddress" placeholder="Delivery address"></textarea><textarea id="mNotes" placeholder="Private notes"></textarea><div class="modal-actions"><button class="primary" type="submit">Save Booking</button></div></form>`;$('bookingModal').classList.remove('hidden');$('manualForm').addEventListener('submit',saveManual);
}
async function saveManual(e){e.preventDefault();const {error}=await window.supabaseClient.from('bookings').insert({customer_name:$('mName').value,phone:$('mPhone').value,package_name:$('mPackage').value,booking_date:$('mDate').value,delivery_address:$('mAddress').value,owner_notes:$('mNotes').value,status:'confirmed',distance_km:0,delivery_fee:0});if(error)alert(error.message);else{$('bookingModal').classList.add('hidden');selectedDate=$('mDate').value;await loadBookings();}}
$('loginForm').addEventListener('submit',signIn);$('prevMonth').onclick=()=>{currentDate.setMonth(currentDate.getMonth()-1);renderCalendar();};$('nextMonth').onclick=()=>{currentDate.setMonth(currentDate.getMonth()+1);renderCalendar();};$('todayBtn').onclick=()=>{currentDate=new Date();selectedDate=isoDate(currentDate);renderCalendar();renderDay(selectedDate);};$('refreshBtn').onclick=loadBookings;$('addBookingBtn').onclick=openAddBooking;$('closeModal').onclick=()=>$('bookingModal').classList.add('hidden');$('logoutBtn').onclick=async()=>{await window.supabaseClient.auth.signOut();$('appView').classList.add('hidden');$('loginView').classList.remove('hidden');};
window.replyBooking=replyBooking;window.openMap=openMap;window.callCustomer=callCustomer;window.openNotes=openNotes;window.saveNotes=saveNotes;window.setStatus=setStatus;
(async()=>{if(!window.supabaseClient){$('loginMessage').textContent='Configure owner-config.js with your Supabase project first.';return;}const {data}=await window.supabaseClient.auth.getSession();if(data.session)showApp();})();
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(console.error));
