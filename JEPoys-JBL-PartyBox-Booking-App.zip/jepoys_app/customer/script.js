const BUSINESS_LAT = 15.989299;
const BUSINESS_LNG = 120.2244473;
let customerGPS = null;
let currentDistanceKm = null;
let currentDeliveryFee = null;

function calculateStraightLineKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const rad = x => x * Math.PI / 180;
  const dLat = rad(lat2 - lat1);
  const dLon = rad(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

async function calculateRoadDistance(lat, lng) {
  const url = `https://router.project-osrm.org/route/v1/driving/${BUSINESS_LNG},${BUSINESS_LAT};${lng},${lat}?overview=false`;
  const response = await fetch(url);
  if (!response.ok) throw new Error('Routing service unavailable');
  const data = await response.json();
  if (data.code !== 'Ok' || !data.routes?.length) throw new Error('No driving route found');
  return data.routes[0].distance / 1000;
}

function calculateDeliveryFee(km) {
  if (km <= 5) return 0;
  if (km <= 8) return 100;
  return 100 + Math.ceil((km - 8) / 3) * 50;
}

function showResult(km, usingFallback = false) {
  currentDistanceKm = Number(km.toFixed(2));
  currentDeliveryFee = calculateDeliveryFee(currentDistanceKm);
  document.getElementById('distance').textContent = currentDistanceKm.toFixed(2) + ' km';
  document.getElementById('fee').textContent = currentDeliveryFee === 0 ? 'FREE' : '₱' + currentDeliveryFee.toLocaleString();
  document.getElementById('result').innerHTML = usingFallback
    ? `⚠️ Road route unavailable. Straight-line distance: <b>${currentDistanceKm.toFixed(2)} km</b>. Please try again before booking.`
    : currentDeliveryFee === 0
      ? `📍 Driving distance: <b>${currentDistanceKm.toFixed(2)} km</b> — <b>FREE DELIVERY</b>`
      : `📍 Driving distance: <b>${currentDistanceKm.toFixed(2)} km</b> — <b>₱${currentDeliveryFee.toLocaleString()} delivery</b>`;
}

async function locate() {
  const result = document.getElementById('result');
  if (!navigator.geolocation) { result.textContent = 'Your browser does not support location.'; return; }
  result.textContent = '📍 Getting your current location…';
  navigator.geolocation.getCurrentPosition(async position => {
    const lat = position.coords.latitude;
    const lng = position.coords.longitude;
    customerGPS = { lat, lng };
    document.getElementById('address').value = 'Current GPS location selected. Please add your complete address.';
    result.textContent = '🚗 Calculating driving distance…';
    try {
      showResult(await calculateRoadDistance(lat, lng));
    } catch (error) {
      console.error(error);
      currentDistanceKm = null;
      currentDeliveryFee = null;
      document.getElementById('distance').textContent = 'Not calculated';
      document.getElementById('fee').textContent = 'Not calculated';
      result.textContent = '❌ Could not calculate driving distance. Please try again.';
    }
  }, error => {
    result.textContent = error.code === 1
      ? '❌ Location permission denied. Please allow location access and try again.'
      : '❌ Location unavailable. Please turn on Location and try again.';
  }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
}

async function submitBooking(event) {
  event.preventDefault();
  if (!customerGPS || currentDistanceKm === null) {
    alert('Please use your current location and calculate the driving distance first.');
    return;
  }
  if (typeof window.supabaseClient === 'undefined') {
    alert('Booking database is not configured yet. Please contact the website owner.');
    return;
  }
  const button = event.submitter;
  if (button) { button.disabled = true; button.textContent = 'Saving booking…'; }
  const payload = {
    customer_name: document.getElementById('name').value.trim(),
    phone: document.getElementById('phone').value.trim(),
    package_name: document.getElementById('package').value,
    booking_date: document.getElementById('date').value,
    delivery_address: document.getElementById('address').value.trim(),
    latitude: customerGPS.lat,
    longitude: customerGPS.lng,
    distance_km: currentDistanceKm,
    delivery_fee: currentDeliveryFee,
    status: 'pending',
    owner_notes: ''
  };
  const { error } = await window.supabaseClient.from('bookings').insert(payload);
  if (error) {
    console.error(error);
    alert('We could not save your booking. Please try again.');
    if (button) { button.disabled = false; button.textContent = 'Send Booking Request'; }
    return;
  }
  document.getElementById('result').innerHTML = '✅ <b>Booking request sent!</b><br>JEPOY\'S JBL PARTYBOX will contact you through Messenger to confirm your booking.';
  alert('Booking request sent successfully!');
  document.getElementById('bookingForm').reset();
  document.getElementById('distance').textContent = 'Not calculated';
  document.getElementById('fee').textContent = 'Not calculated';
  currentDistanceKm = null;
  currentDeliveryFee = null;
  customerGPS = null;
  if (button) { button.disabled = false; button.textContent = 'Send Booking Request'; }
}

document.getElementById('locationBtn')?.addEventListener('click', locate);
document.getElementById('calc')?.addEventListener('click', locate);
document.getElementById('bookingForm')?.addEventListener('submit', submitBooking);

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(console.error));
}
