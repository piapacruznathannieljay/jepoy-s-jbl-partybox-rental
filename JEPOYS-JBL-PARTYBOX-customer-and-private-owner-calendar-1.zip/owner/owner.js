const client = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
let currentDate = new Date();
let bookings = [];
let selectedBooking = null;

const $ = id => document.getElementById(id);
const pad = n => String(n).padStart(2,"0");
const dateKey = d => `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;

async function login(){
  const email=$("email").value.trim(), password=$("password").value;
  $("loginMsg").textContent="Signing in...";
  const {error}=await client.auth.signInWithPassword({email,password});
  $("loginMsg").textContent=error?error.message:"";
  if(!error) showApp();
}
async function logout(){await client.auth.signOut(); $("app").classList.add("hidden"); $("loginScreen").classList.remove("hidden");}
async function showApp(){ $("loginScreen").classList.add("hidden"); $("app").classList.remove("hidden"); await loadBookings(); render(); }

async function loadBookings(){
  $("status").textContent="Loading bookings...";
  const {data,error}=await client.from("bookings").select("*").order("date",{ascending:true});
  if(error){$("status").textContent="Database error: "+error.message; bookings=[]; return;}
  bookings=data||[];
  $("status").textContent=`${bookings.length} booking(s) loaded.`;
}

function monthName(d){return d.toLocaleDateString("en-US",{month:"long",year:"numeric"});}
function render(){
  $("monthTitle").textContent=monthName(currentDate);
  const y=currentDate.getFullYear(), m=currentDate.getMonth();
  const first=new Date(y,m,1), start=new Date(y,m,1-first.getDay());
  const grid=$("calendarGrid"); grid.innerHTML="";
  for(let i=0;i<42;i++){
    const d=new Date(start); d.setDate(start.getDate()+i);
    const cell=document.createElement("div");
    cell.className="day"+(d.getMonth()!==m?" other":"")+(dateKey(d)===dateKey(new Date())?" today":"");
    cell.innerHTML=`<div class="num">${d.getDate()}</div>`;
    bookings.filter(b=>String(b.date).slice(0,10)===dateKey(d)).forEach(b=>{
      const ev=document.createElement("div");
      ev.className="event "+String(b.status||"pending").toLowerCase();
      ev.textContent=(b.name||"Booking")+" • "+(b.package||"");
      ev.onclick=e=>{e.stopPropagation();openDetails(b);};
      cell.appendChild(ev);
    });
    cell.onclick=()=>{ $("date").value=dateKey(d); };
    grid.appendChild(cell);
  }
  renderList();
}
function renderList(){
  const list=$("bookingList"); list.innerHTML="";
  const sorted=[...bookings].sort((a,b)=>String(a.date).localeCompare(String(b.date)));
  if(!sorted.length){list.innerHTML='<p class="muted">No bookings yet.</p>';return;}
  sorted.forEach(b=>{
    const div=document.createElement("div"); div.className="booking";
    div.innerHTML=`<div class="info"><h3>${esc(b.name||"Unnamed customer")}</h3><div class="muted">${esc(b.date||"No date")} • ${esc(b.package||"No package")}<br>${esc(b.phone||"")}<br>${esc(b.address||"")}</div></div><span class="badge">${esc(b.status||"pending")}</span><button class="smallBtn">View</button>`;
    div.querySelector("button").onclick=()=>openDetails(b);
    list.appendChild(div);
  });
}
function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}

function openDetails(b){
  selectedBooking=b;
  $("detailName").textContent=b.name||"Booking";
  $("detailBody").innerHTML=`
  <p><b>Date:</b> ${esc(b.date)}</p>
  <p><b>Package:</b> ${esc(b.package)}</p>
  <p><b>Contact:</b> ${esc(b.phone)}</p>
  <p><b>Address:</b> ${esc(b.address)}</p>
  <p><b>Distance:</b> ${esc(b.distance||"Not recorded")}</p>
  <p><b>Delivery fee:</b> ${esc(b.delivery_fee||"Not recorded")}</p>
  <p><b>Status:</b> ${esc(b.status||"pending")}</p>`;
  $("callBtn").href="tel:"+(b.phone||"");
  const map=b.maps_link||((b.lat&&b.lng)?`https://www.google.com/maps?q=${b.lat},${b.lng}`:"#");
  $("mapBtn").href=map;
  $("detailsModal").classList.remove("hidden");
}
async function setStatus(status){
  if(!selectedBooking)return;
  const {error}=await client.from("bookings").update({status}).eq("id",selectedBooking.id);
  if(error){alert(error.message);return;}
  $("detailsModal").classList.add("hidden"); await loadBookings(); render();
}

$("loginBtn").onclick=login;
$("logoutBtn").onclick=logout;
$("prevBtn").onclick=()=>{currentDate.setMonth(currentDate.getMonth()-1);render();};
$("nextBtn").onclick=()=>{currentDate.setMonth(currentDate.getMonth()+1);render();};
$("todayBtn").onclick=()=>{currentDate=new Date();render();};
$("refreshBtn").onclick=async()=>{await loadBookings();render();};
$("closeModal").onclick=()=>$("detailsModal").classList.add("hidden");
$("confirmBtn").onclick=()=>setStatus("confirmed");
$("cancelBtn").onclick=()=>setStatus("cancelled");
$("detailsModal").onclick=e=>{if(e.target.id==="detailsModal")$("detailsModal").classList.add("hidden")};

client.auth.getSession().then(({data})=>{if(data.session)showApp();});
