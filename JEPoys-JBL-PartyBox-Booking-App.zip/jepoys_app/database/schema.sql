-- JEPOY'S JBL PARTYBOX booking database
-- Run this in Supabase Dashboard -> SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  customer_name text not null,
  phone text not null,
  package_name text not null,
  booking_date date not null,
  delivery_address text not null,
  latitude double precision,
  longitude double precision,
  distance_km numeric(10,2) not null default 0,
  delivery_fee numeric(10,2) not null default 0,
  status text not null default 'pending' check (status in ('pending','confirmed','completed','cancelled')),
  owner_notes text not null default ''
);

alter table public.bookings enable row level security;

-- Public website can submit bookings but cannot read existing bookings.
drop policy if exists "public can create bookings" on public.bookings;
create policy "public can create bookings"
on public.bookings for insert
to anon, authenticated
with check (true);

-- Only signed-in owner users can read/update/delete bookings.
drop policy if exists "owner can read bookings" on public.bookings;
create policy "owner can read bookings"
on public.bookings for select
to authenticated
using (true);

drop policy if exists "owner can update bookings" on public.bookings;
create policy "owner can update bookings"
on public.bookings for update
to authenticated
using (true)
with check (true);

drop policy if exists "owner can delete bookings" on public.bookings;
create policy "owner can delete bookings"
on public.bookings for delete
to authenticated
using (true);

-- Optional: enable realtime so the owner app can refresh when a new booking is inserted.
alter publication supabase_realtime add table public.bookings;
