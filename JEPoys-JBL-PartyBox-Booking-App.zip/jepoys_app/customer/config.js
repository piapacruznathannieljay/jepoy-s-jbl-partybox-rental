// JEPOY'S JBL PARTYBOX - Supabase configuration
// Replace these two values with your Supabase project's values.
// Supabase Dashboard -> Project Settings -> API
const SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";
