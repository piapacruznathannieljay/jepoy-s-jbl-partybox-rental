JEPOY'S JBL PARTYBOX — CUSTOMER + PRIVATE OWNER CALENDAR

Folder structure:
  index.html
  style.css
  script.js
  config.js
  manifest.json
  sw.js
  owner/
    owner.html
    owner.css
    owner.js
    manifest.json
  supabase-bookings.sql

IMPORTANT:
1. The owner calendar is private because it requires Supabase email/password login.
2. Create the bookings table using supabase-bookings.sql.
3. Create your owner account in Supabase Authentication.
4. Put your Supabase Project URL and anon key into config.js.
5. Upload the files to GitHub Pages.
6. Customer site is the public part.
7. Owner app is at /owner/owner.html and can be installed separately as an app.
8. The existing customer script currently opens Messenger. To make customer bookings automatically appear in the owner calendar, the customer script must also insert the booking into Supabase. The current code was intentionally left unchanged as requested; this package therefore provides the private calendar and database table, but does not silently change the existing Messenger booking flow.

SECURITY:
Do not put a Supabase service_role key in the website. Only use the anon/publishable key with Row Level Security enabled.
