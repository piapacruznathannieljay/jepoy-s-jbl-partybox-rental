# JEPOY'S JBL PARTYBOX - Customer Website + Private Owner App

## What is included
- `customer/` — public booking website. Customers do not need to install an app.
- `owner/` — private calendar-style owner app. Only your owner account should be allowed to sign in.
- `database/schema.sql` — Supabase database table and security policies.

## Setup
1. Create a Supabase project.
2. In Supabase SQL Editor, run `database/schema.sql`.
3. In Supabase Authentication -> Users, create your owner email/password account.
4. Copy your Supabase Project URL and anon key from Project Settings -> API.
5. Put those values into BOTH `customer/config.js` and `owner/owner-config.js`.
6. Publish `customer/` with GitHub Pages. If using the repository root, move/copy the contents of `customer/` into the root.
7. Publish `owner/` separately with GitHub Pages or another static host. Keep the owner URL private.
8. Install the owner app from Chrome using Add to Home screen / Install app.

## Messenger reply
The owner app's Reply button opens JEPOY'S JBL PARTYBOX Messenger page. It does not create a separate chat system. The customer booking remains saved in the database.

## Important
GitHub Pages is static hosting. Supabase is what stores the bookings and protects the private owner calendar.
